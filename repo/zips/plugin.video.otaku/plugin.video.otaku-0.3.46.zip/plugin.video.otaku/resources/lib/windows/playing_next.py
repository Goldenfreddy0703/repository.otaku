from kodi_six import xbmc
from resources.lib.ui import control
from resources.lib.windows.base_window import BaseWindow


class PlayingNext(BaseWindow):

    def __init__(self, xml_file, xml_location, actionArgs=None):

        try:
            super(PlayingNext, self).__init__(xml_file, xml_location, actionArgs=actionArgs)
            self.player = control.player()
            self.playing_file = self.player.getPlayingFile()
            self.duration = self.player.getTotalTime() - self.player.getTime()
            self.closed = False
            self.actioned = None
            self.default_action = control.getSetting('playingnext.defaultaction')

        except:
            import traceback
            traceback.print_exc()

    def onInit(self):
        self.background_tasks()

    def calculate_percent(self):
        return ((int(self.player.getTotalTime()) - int(self.player.getTime())) / float(self.duration)) * 100

    def background_tasks(self):
        try:
            try:
                progress_bar = self.getControl(3014)
            except:
                progress_bar = None

            while int(self.player.getTotalTime()) - int(self.player.getTime()) > 2 and not self.closed \
                    and self.playing_file == self.player.getPlayingFile():
                xbmc.sleep(500)
                if progress_bar is not None:
                    progress_bar.setPercent(self.calculate_percent())

            if self.default_action == '1' and\
                    self.playing_file == self.player.getPlayingFile() and\
                    not self.actioned:
                self.player.pause()
        except:
            import traceback
            traceback.print_exc()

        self.close()

    def doModal(self):
        try:
            super(PlayingNext, self).doModal()
        except:
            import traceback
            traceback.print_exc()

    def close(self):
        self.closed = True
        super(PlayingNext, self).close()

    def onClick(self, control_id):
        self.handle_action(7, control_id)

    def handle_action(self, action, control_id=None):
        if control_id is None:
            control_id = self.getFocusId()

        if control_id == 3001:
            self.actioned = True
            # self.player.seekTime(self.player.getTotalTime())
            xbmc.executebuiltin('PlayerControl(BigSkipForward)')
            self.close()
        if control_id == 3002:
            self.actioned = True
            self.close()
        if control_id == 3003:
            self.actioned = True
            skipoutro_end_skip_time = int(control.getSetting('skipoutro.end.skip.time'))
            if skipoutro_end_skip_time != 0:
                self.player.seekTime(skipoutro_end_skip_time)
            self.close()

    def onAction(self, action):

        actionID = action.getId()

        if actionID in [92, 10, 100, 401]:
            # BACKSPACE / ESCAPE
            self.close()

        if actionID == 7:
            self.handle_action(actionID)
            return
